from PyQt5.QtCore import pyqtSignal
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import QMessageBox
from qgis.core import Qgis, QgsGeometry, QgsFeature, QgsMessageLog, QgsDistanceArea, QgsCoordinateTransformContext, \
    QgsWkbTypes
from qgis.gui import QgsMapToolIdentify, QgsMapToolIdentifyFeature, QgsMapTool, QgsRubberBand, QgsMessageBar
from qgis.PyQt.QtCore import Qt


#  clase para seleccionar features
# ????
class SelectTool(QgsMapToolIdentify):
    def __init__(self, window):
        QgsMapToolIdentify.__init__(self, window.mapCanvas)
        self.window = window
        self.setCursor(Qt.ArrowCursor)

    def canvasReleaseEvent(self, event):
        found_features = self.identify(event.x(), event.y(), self.TopDownStopAtFirst, self.VectorLayer)
        if len(found_features) > 0:
            layer = found_features[0].mLayer
            feature = found_features[0].mFeature

            if event.modifiers() & Qt.ShiftModifier:
                layer.select(feature.id())
            else:
                layer.setSelectedFeatures([feature.id()])
        else:
            self.window.layer.removeSelection()


# Map Tool para agregar un punto a una capa
class AddPointTool(QgsMapTool):
    def __init__(self, canvas, layer):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.layer = layer
        self.layer.startEditing()
        self.saveChanges = False
        self.setCursor(Qt.CrossCursor)

    def canvasReleaseEvent(self, event):
        if event.button() == Qt.RightButton:
            btn = QMessageBox.question(
                self.canvas,
                "Confirmar!",
                f"Desea Guardar los cambios en la capa {self.layer.name()}",
                buttons=QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
                defaultButton=QMessageBox.Cancel,
            )
            if btn == QMessageBox.Cancel:
                return

            if btn == QMessageBox.Yes:
                self.saveChanges = True
            else:
                self.saveChanges = False

            self.deactivate()

        else:
            point = self.toLayerCoordinates(self.layer, event.pos())
            feature = QgsFeature(self.layer.fields())
            feature.setGeometry(QgsGeometry.fromPointXY(point))
            self.layer.addFeatures([feature])
            self.layer.updateExtents()
            self.canvas.refresh()

    def deactivate(self):
        if self.saveChanges:
            self.layer.commitChanges()
        else:
            self.layer.rollBack()

        self.setCursor(Qt.ArrowCursor)


# MapTool para seleccionar y mover un punto
# ????
class MovePointTool(QgsMapToolIdentify):
    def __init__(self, mapCanvas, layer):
        QgsMapToolIdentify.__init__(self, mapCanvas)
        self.canvas = mapCanvas
        self.layer = layer
        self.layer.startEditing()
        self.dragging = False
        self.feature = None
        self.saveChanges = False
        self.setCursor(Qt.CrossCursor)

    def canvasPressEvent(self, event):
        found_features = self.identify(event.x(), event.y(), [self.layer], self.TopDownStopAtFirst)
        if len(found_features) > 0:
            self.dragging = True
            # self.layer.startEditing()
            self.feature = QgsFeature(found_features[0].mFeature)
        else:
            self.dragging = False
            self.feature = None

    def canvasMoveEvent(self, event):
        if self.dragging:
            point = self.toLayerCoordinates(self.layer, event.pos())
            geometry = QgsGeometry.fromPointXY(point)
            self.layer.changeGeometry(self.feature.id(), geometry)
            self.layer.triggerRepaint()
            self.canvas.refresh()

    def canvasReleaseEvent(self, event):
        self.dragging = False
        self.feature = None

        if event.button() == Qt.RightButton:
            btn = QMessageBox.question(
                self.canvas,
                "Confirmar!",
                f"Desea Guardar los cambios en la capa {self.layer.name()}",
                buttons=QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
                defaultButton=QMessageBox.Cancel,
            )
            if btn == QMessageBox.Cancel:
                return

            if btn == QMessageBox.Yes:
                self.saveChanges = True
            else:
                self.saveChanges = False

            self.deactivate()

    def deactivate(self):
        if self.saveChanges:
            self.layer.commitChanges()
        else:
            self.layer.rollBack()

        self.setCursor(Qt.ArrowCursor)


# Eliminar Tool
class DeleteTool(QgsMapToolIdentifyFeature):
    def __init__(self, mapCanvas, layer):
        QgsMapToolIdentifyFeature.__init__(self, mapCanvas)
        self.setCursor(Qt.CrossCursor)
        self.layer = layer
        self.layer.startEditing()
        self.feature = None

    def canvasPressEvent(self, event):
        found_features = self.identify(event.x(), event.y(), [self.layer], self.TopDownAll)
        if len(found_features) > 0:
            self.feature = QgsFeature(found_features[0].mFeature)
        else:
            self.feature = None

    def canvasReleaseEvent(self, event):
        found_features = self.identify(event.x(), event.y(), [self.layer], self.TopDownAll)
        if len(found_features) > 0:
            if self.feature.id() == found_features[0].mFeature.id():
                self.layer.deleteFeature(self.feature.id())

    def deactivate(self):
        self.layer.commitChanges()
        self.setCursor(Qt.ArrowCursor)


# MapTool calcular distancia entre 2 puntos
class DistanceCalculator(QgsMapTool):
    def __init__(self, iface):
        QgsMapTool.__init__(self, iface.mapCanvas())
        self.iface = iface

    def canvasPressEvent(self, event):
        transform = self.iface.mapCanvas().getCoordinateTransform()
        self._startPt = transform.toMapCoordinates(event.pos().x(),
                                                   event.pos().y())

    def canvasReleaseEvent(self, event):
        transform = self.iface.mapCanvas().getCoordinateTransform()
        endPt = transform.toMapCoordinates(event.pos().x(),
                                           event.pos().y())

        crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        context = QgsCoordinateTransformContext()
        distance_calc = QgsDistanceArea()
        distance_calc.setSourceCrs(crs, context)
        distance_calc.setEllipsoid(crs.ellipsoidAcronym())
        # distance_calc.setEllipsoidalMode(crs.geographicFlag())
        distance = distance_calc.measureLine([self._startPt, endPt]) / 1000

        messageBar = self.iface.messageBar()
        messageBar.pushMessage("Distance = %d km" % distance,
                               level=Qgis.Info,
                               duration=2)


# Capture Tool
class CaptureTool(QgsMapTool):
    CAPTURE_LINE = 1
    CAPTURE_POLYGON = 2

    def __init__(self, canvas, layer, onGeometryAdded, captureMode):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.layer = layer
        self.onGeometryAdded = onGeometryAdded
        self.captureMode = captureMode
        self.rubberBand = None
        self.tempRubberBand = None
        self.capturedPoints = []
        self.capturing = False
        self.setCursor(Qt.CrossCursor)

    def canvasReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            if not self.capturing:
                self.startCapturing()

            self.addVertex(event.pos())
        elif event.button() == Qt.RightButton:
            points = self.getCapturedGeometry()
            self.stopCapturing()
            if points:
                self.geometryCaptured(points)

    def canvasMoveEvent(self, event):
        if self.tempRubberBand and self.capturing:
            mapPt, layerPt = self.transformCoordinates(event.pos())
            self.tempRubberBand.movePoint(mapPt)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Backspace or event.key() == Qt.Key_Delete:
            self.removeLastVertex()
            event.ignore()

        if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
            points = self.getCapturedGeometry()
            self.stopCapturing()
            if points:
                self.geometryCaptured(points)

    def transformCoordinates(self, canvasPt):
        return (self.toMapCoordinates(canvasPt),
                self.toLayerCoordinates(self.layer, canvasPt))

    def startCapturing(self):
        color = QColor("red")
        color.setAlphaF(0.78)

        self.rubberBand = QgsRubberBand(self.canvas, self.bandType())
        self.rubberBand.setWidth(2)
        self.rubberBand.setColor(color)
        self.rubberBand.show()

        self.tempRubberBand = QgsRubberBand(self.canvas, self.bandType())
        self.tempRubberBand.setWidth(2)
        self.tempRubberBand.setColor(color)
        self.tempRubberBand.setLineStyle(Qt.DotLine)
        self.tempRubberBand.show()

        self.capturing = True

    def bandType(self):
        if self.captureMode == CaptureTool.CAPTURE_POLYGON:
            return QgsWkbTypes.PolygonGeometry
        else:
            return QgsWkbTypes.LineGeometry

    def stopCapturing(self):
        if self.rubberBand:
            self.canvas.scene().removeItem(self.rubberBand)
            self.rubberBand = None

        if self.tempRubberBand:
            self.canvas.scene().removeItem(self.tempRubberBand)
            self.tempRubberBand = None

        self.capturing = False
        self.capturedPoints = []
        self.canvas.refresh()

    def addVertex(self, canvasPoint):
        mapPt, layerPt = self.transformCoordinates(canvasPoint)

        self.rubberBand.addPoint(mapPt)
        self.capturedPoints.append(layerPt)

        self.tempRubberBand.reset(self.bandType())

        if self.captureMode == CaptureTool.CAPTURE_LINE:
            self.tempRubberBand.addPoint(mapPt)
        elif self.captureMode == CaptureTool.CAPTURE_POLYGON:
            firstPoint = self.rubberBand.getPoint(0, 0)
            self.tempRubberBand.addPoint(firstPoint)
            self.tempRubberBand.movePoint(mapPt)
            self.tempRubberBand.addPoint(mapPt)

    def removeLastVertex(self):
        if not self.capturing: return

        bandSize = self.rubberBand.numberOfVertices()
        tempBandSize = self.tempRubberBand.numberOfVertices()
        numPoints = len(self.capturedPoints)

        if bandSize < 1 or numPoints < 1:
            return

        self.rubberBand.removePoint(-1)

        if bandSize > 1:
            if tempBandSize > 1:
                point = self.rubberBand.getPoint(0, bandSize - 2)
                self.tempRubberBand.movePoint(tempBandSize - 2, point)
        else:
            self.tempRubberBand.reset(self.bandType())

        del self.capturedPoints[-1]

    def getCapturedGeometry(self):
        points = self.capturedPoints

        if self.captureMode == CaptureTool.CAPTURE_LINE:
            if len(points) < 2:
                return None

        if self.captureMode == CaptureTool.CAPTURE_POLYGON:
            if len(points) < 3:
                return None

        if self.captureMode == CaptureTool.CAPTURE_POLYGON:
            points.append(points[0])  # Close polygon.

        return points

    def geometryCaptured(self, layerCoords):
        feature = QgsFeature(self.layer.fields())

        if self.captureMode == CaptureTool.CAPTURE_LINE:
            feature.setGeometry(QgsGeometry.fromPolylineXY(layerCoords))

        elif self.captureMode == CaptureTool.CAPTURE_POLYGON:
            feature.setGeometry(QgsGeometry.fromPolygonXY([layerCoords]))

        self.layer.startEditing()
        self.layer.addFeature(feature)
        self.layer.commitChanges()
        self.layer.updateExtents()
        self.onGeometryAdded()

    def deactivate(self):
        self.setCursor(Qt.ArrowCursor)

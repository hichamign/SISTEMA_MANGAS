from PyQt5.QtCore import pyqtSignal
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import QMessageBox
from qgis._core import QgsPoint, QgsVectorLayer, QgsProject
from qgis.core import Qgis, QgsGeometry, QgsFeature, QgsPointXY, QgsFeatureRequest, QgsExpression, QgsRenderContext, QgsWkbTypes, QgsMessageLog
from qgis.gui import QgsMapToolIdentify, QgsMapTool, QgsRubberBand, QgsMessageBar
from qgis.PyQt.QtCore import Qt

import processing


# retorna el proximo id
def getNextId(layer):
    idx = layer.fields().indexOf("id")
    maxId = layer.maximumValue(idx)
    if not maxId or maxId < 0:
        return 1
    else:
        return maxId + 1


def getPadreId(punto_id, layer_lineas):
    expression = f""" "punto_final_id" = {punto_id} """
    res = layer_lineas.getFeatures(QgsFeatureRequest(QgsExpression(expression)))
    lineas = [l for l in res]
    if len(lineas) > 0:
        return lineas[0]["id"]
    else:
        return None


def getLineasDePunto(punto_id, layer_lineas):
    expression = f""" "punto_inicial_id" = {punto_id} or "punto_final_id" = {punto_id} """
    lineas = layer_lineas.getFeatures(QgsFeatureRequest(QgsExpression(expression)))
    return [l for l in lineas]


def getLineasNacientesDePunto(punto_id, layer_lineas):
    expression = f""" "punto_inicial_id" = {punto_id} """
    lineas = layer_lineas.getFeatures(QgsFeatureRequest(QgsExpression(expression)))
    return [l for l in lineas]


def getLineasHijas(linea_id, layer_lineas):
    expression = f""" "padre_id" = {linea_id} """
    res = layer_lineas.getFeatures(QgsFeatureRequest(QgsExpression(expression)))
    return [l for l in res]


def getFeatureById(feat_id, layer):
    expression = f""" "id" = {feat_id} """
    res = layer.getFeatures(QgsFeatureRequest(QgsExpression(expression)))
    features = [f for f in res]
    if len(features) > 0:
        return features[0]
    else:
        return None


def getCompuertas(linea_id, layer_compuertas):
    expression = f""" "manga_id" = {linea_id} """
    res = layer_compuertas.getFeatures(QgsFeatureRequest(QgsExpression(expression)))
    return [c for c in res]


def getRiego(linea_id, layer_riego, tipo):
    expression = f""" "id" = {linea_id} and "tipo" = '{tipo}' """
    res = layer_riego.getFeatures(QgsFeatureRequest(QgsExpression(expression)))
    features = [f for f in res]
    if len(features) > 0:
        return features[0]
    else:
        return None


def eliminarCompuertas(manga_id, layer_compuertas, layer_riegos_compuertas):
    compuertas = getCompuertas(manga_id, layer_compuertas)

    ids_comp = []
    ids_riegos = []
    for c in compuertas:
        riego_compuerta = getFeatureById(c["id"], layer_riegos_compuertas)
        if riego_compuerta:
            ids_riegos.append(riego_compuerta.id())

        ids_comp.append(c.id())

    layer_compuertas.dataProvider().deleteFeatures(ids_comp)
    layer_riegos_compuertas.dataProvider().deleteFeatures(ids_riegos)
    layer_compuertas.triggerRepaint()
    layer_riegos_compuertas.triggerRepaint()


# Map Tool para agregar un punto a una capa
class AddPuntoInicialTool(QgsMapTool):
    def __init__(self, proyecto):
        self.canvas = proyecto.iface.mapCanvas()
        self.pry = proyecto
        QgsMapTool.__init__(self, self.canvas)
        self.setCursor(Qt.CrossCursor)
        self.pry.iface.messageBar().pushMessage("Click inzquierdo para agregar | Click derecho, ENTER o ESC para salir!",
                               level=Qgis.Info, duration=5)

    def canvasReleaseEvent(self, event):
        point = self.toLayerCoordinates(self.pry.layer_puntos, event.pos())
        feature = QgsFeature(self.pry.layer_puntos.fields())
        feature.setGeometry(QgsGeometry.fromPointXY(point))

        enRonda, ptoTaipas = self.puntoEnRonda(feature)
        if not enRonda:
            return

        feature["id"] = getNextId(self.pry.layer_puntos)
        feature["tipo"] = "INICIAL"
        feature["taipas"] = ptoTaipas

        self.pry.layer_puntos.dataProvider().addFeatures([feature])
        self.pry.layer_puntos.triggerRepaint()
        self.canvas.refresh()

    def puntoEnRonda(self, punto):
        for ronda in self.pry.layer_rondas.getFeatures():
            if punto.geometry().intersects(ronda.geometry()):
                return True, ronda["taipas"]

        return False, ""

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape or event.key() == Qt.Key_Enter or event.key() == Qt.Key_Return:
            self.deactivate()

    def deactivate(self):
        self.setCursor(Qt.ArrowCursor)


# Eliminar Tool
class DelPuntoInicialTool(QgsMapToolIdentify):

    def __init__(self, proyecto):
        self.canvas = proyecto.iface.mapCanvas()
        self.pry = proyecto
        QgsMapToolIdentify.__init__(self, self.canvas)
        self.feature = None
        self.setCursor(Qt.CrossCursor)

        self.pry.iface.messageBar().pushMessage("Click inzquierdo para eliminar | Click derecho, ENTER o ESC para salir!",
                               level=Qgis.Info, duration=5)

    def canvasPressEvent(self, event):
        found_features = self.identify(event.x(), event.y(), [self.pry.layer_puntos], self.TopDownAll)
        if len(found_features) > 0:
            self.feature = QgsFeature(found_features[0].mFeature)
        else:
            self.feature = None

    def canvasReleaseEvent(self, event):
        found_features = self.identify(event.x(), event.y(), [self.pry.layer_puntos], self.TopDownAll)
        if len(found_features) == 0:
            return

        if not self.feature.id() == found_features[0].mFeature.id():
            return

        if getLineasDePunto(self.feature["id"], self.pry.layer_lineas):
            QMessageBox.warning(self.canvas, "Error",
                                "No se puede eliminar el Punto por que tiene mangas asociadas!")
            return

        self.pry.layer_puntos.dataProvider().deleteFeatures([self.feature.id()])
        self.pry.layer_puntos.triggerRepaint()
        self.canvas.refresh()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape or event.key() == Qt.Key_Enter or event.key() == Qt.Key_Return:
            self.deactivate()

    def deactivate(self):
        self.setCursor(Qt.ArrowCursor)


class AddMangasTool(QgsMapTool):

    def __init__(self, pry):
        self.canvas = pry.iface.mapCanvas()
        self.pry = pry
        QgsMapTool.__init__(self, self.canvas)
        self.tool = QgsMapToolIdentify(self.canvas)

        self.linea = None
        self.manga = None
        self.tipo_manga = None
        self.riego_cruza = None
        self.riego_no_cruza = None
        self.padre_id = None
        self.punto_inicial = None
        self.punto_final = None
        self.puntos = []
        self.capturing = False
        self.ancho_riego = self.pry.wnd.ancho_riego.value()
        self.supero_capacidad = False
        self.rubberBand = None

        self.pto_final_idx = self.pry.layer_lineas.fields().indexOf("punto_final_id")
        self.long_idx = self.pry.layer_lineas.fields().indexOf("longitud")
        self.area_idx = self.pry.layer_lineas.fields().indexOf("area")

        self.tipos_mangas = [
            {
                'desc': 'Manga 10 (15ha)',
                'tipo': "M10",
                'capacidad': 15,
            },
            {
                'desc': 'Manga 12 (25ha)',
                'tipo': "M12",
                'capacidad': 25,
            },
            {
                'desc': 'Manga 15 (35ha)',
                'tipo': "M15",
                'capacidad': 35,
            },
            {
                'desc': 'Manga 18 (60ha)',
                'tipo': "M18",
                'capacidad': 60,
            },
            {
                'desc': 'Manga 22 (120ha)',
                'tipo': "M22",
                'capacidad': 120,
            },
        ]

        self.msg_tipos = QMessageBox(QMessageBox.Question, "Tipo de Manga", "Seleccione el tipo de manga a diseñar",
                                     QMessageBox.Cancel, self.canvas)
        for tipo in self.tipos_mangas:
            self.msg_tipos.addButton(tipo['desc'], QMessageBox.YesRole)

        self.setCursor(Qt.CrossCursor)

        self.pry.iface.messageBar().pushMessage("Click inzquierdo para seleccionar punto inicial o agregar vertice | Click derecho para Terminar manga",
            level=Qgis.Info, duration=5)

    def canvasReleaseEvent(self, event):
        if self.capturing and self.supero_capacidad:
            QMessageBox.warning(self.canvas, "Advertencia!", "La manga supero su capacidad maxima!")
            return

        if event.button() == Qt.LeftButton:
            if self.capturing:
                pto = self.toLayerCoordinates(self.pry.layer_puntos, event.pos())

                if self.mangaCruzaOtraManga():
                    QMessageBox.warning(self.canvas, "Error", "La manga no puede cruzar otra manga!")
                    return

                self.puntos.append(pto)

                if len(self.puntos) > 2:
                    if self.mangaSeCruzaAsiMisma(self.puntos):
                        QMessageBox.warning(self.canvas, "Error", "La manga no puede cruzarse a si misma!")
                        self.puntos.pop()

            else:
                found_features = self.tool.identify(event.x(), event.y(), [self.pry.layer_puntos], self.tool.TopDownAll)
                if len(found_features) == 0:
                    return

                feature = QgsFeature(found_features[0].mFeature)
                if not feature["tipo"] in ["INICIAL", "FINMANGA"]:
                    QMessageBox.warning(self.canvas, "", "punto no valido!")
                    return

                reply = self.msg_tipos.exec_()

                if reply == QMessageBox.Cancel:
                    return

                self.punto_inicial = feature
                self.puntos.append(self.punto_inicial.geometry().asPoint())
                self.tipo_manga = self.tipos_mangas[reply]

                if not self.punto_inicial["tipo"] == "INICIAL":
                    self.padre_id = getPadreId(self.punto_inicial["id"], self.pry.layer_lineas)

                self.startCapturing()

        elif event.button() == Qt.RightButton:
            if self.capturing:
                pt_final = self.toLayerCoordinates(self.pry.layer_puntos, event.pos())

                if self.mangaCruzaOtraManga():
                    QMessageBox.warning(self.canvas, "Error", "La manga no puede cruzar otra manga!")
                    return

                self.puntos.append(pt_final)

                if len(self.puntos) > 3:
                    if self.mangaSeCruzaAsiMisma(self.puntos):
                        QMessageBox.warning(self.canvas, "Error", "La manga no puede cruzarse a si misma!")
                        self.puntos.pop()
                        return

                punto_final = QgsFeature(self.pry.layer_puntos.fields())
                punto_final.setGeometry(QgsGeometry.fromPointXY(self.puntos[-1]))
                punto_id = getNextId(self.pry.layer_puntos)
                punto_final["id"] = punto_id
                punto_final["tipo"] = "FINMANGA"
                punto_final["taipas"] = self.punto_final_taipas(punto_final)
                self.pry.layer_puntos.dataProvider().addFeatures([punto_final])
                self.pry.layer_puntos.triggerRepaint()
                self.pry.layer_lineas.startEditing()
                self.pry.layer_lineas.changeAttributeValue(self.linea.id(), self.pto_final_idx, punto_id)
                self.pry.layer_lineas.commitChanges()
                self.stopCapturing()

    def canvasMoveEvent(self, event):
        if self.capturing:
            pto_xy = self.toLayerCoordinates(self.pry.layer_puntos, event.pos())
            self.dibujarManga(pto_xy)

    def startCapturing(self):
        linea = QgsFeature(self.pry.layer_lineas.fields())
        linea_id = getNextId(self.pry.layer_lineas)
        linea["id"] = linea_id
        linea["padre_id"] = self.padre_id
        linea["punto_inicial_id"] = self.punto_inicial["id"]
        linea["tipo"] = self.tipo_manga["tipo"]
        linea["capacidad_max"] = self.tipo_manga["capacidad"]
        linea["area"] = 0

        self.pry.layer_lineas.dataProvider().addFeatures([linea])
        self.linea = getFeatureById(linea_id, self.pry.layer_lineas)

        manga = QgsFeature(self.pry.layer_mangas.fields())
        manga["id"] = linea_id
        manga["tipo"] = self.tipo_manga["tipo"]
        self.pry.layer_mangas.dataProvider().addFeatures([manga])
        self.manga = getFeatureById(linea_id, self.pry.layer_mangas)

        riego_cruza = QgsFeature(self.pry.layer_riegos.fields())
        riego_no_cruza = QgsFeature(self.pry.layer_riegos.fields())
        riego_cruza["id"] = linea_id
        riego_cruza["tipo"] = 'CRUZAMANGA'
        riego_no_cruza["id"] = linea_id
        riego_no_cruza["tipo"] = 'NOCRUZAMANGA'
        self.pry.layer_riegos.dataProvider().addFeatures([riego_cruza, riego_no_cruza])
        self.riego_cruza = getRiego(linea_id, self.pry.layer_riegos, "CRUZAMANGA")
        self.riego_no_cruza = getRiego(linea_id, self.pry.layer_riegos, "NOCRUZAMANGA")

        self.supero_capacidad = False
        self.rubberBand = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rubberBand.setWidth(2)
        self.rubberBand.setColor(QColor("red"))
        self.rubberBand.show()

        self.capturing = True

    def stopCapturing(self):
        self.linea = None
        self.manga = None
        self.riego_cruza = None
        self.riego_no_cruza = None
        self.punto_inicial = None
        self.puntos = []
        self.tipos_manga = None

        self.supero_capacidad = False
        if self.rubberBand:
            self.canvas.scene().removeItem(self.rubberBand)
            self.rubberBand = None

        self.capturing = False

        self.refreshCapas()

    def keyPressEvent(self, event):
        if self.capturing:
            if event.key() == Qt.Key_Delete or event.key() == Qt.Key_Backspace:
                if len(self.puntos) > 1:
                    self.puntos.pop()
                    pto_xy = self.toMapCoordinates(self.canvas.mouseLastXY())
                    self.dibujarManga(pto_xy)

                elif len(self.puntos) == 1:
                    self.deleteManga()
        else:
            if event.key() == Qt.Key_Escape or event.key() == Qt.Key_Enter or event.key() == Qt.Key_Return:
                self.deactivate()

    def deleteManga(self):
        self.pry.layer_lineas.dataProvider().deleteFeatures([self.linea.id()])
        self.pry.layer_mangas.dataProvider().deleteFeatures([self.manga.id()])
        self.pry.layer_riegos.dataProvider().deleteFeatures([self.riego_cruza.id()])
        self.pry.layer_riegos.dataProvider().deleteFeatures([self.riego_no_cruza.id()])

        self.stopCapturing()

    def dibujarManga(self, point_xy):
        self.pry.layer_puntos.startEditing()
        self.pry.layer_lineas.startEditing()
        self.pry.layer_mangas.startEditing()
        self.pry.layer_riegos.startEditing()

        linea = QgsGeometry.fromPolylineXY(self.puntos + [point_xy])
        manga = linea.buffer(3, 1, QgsGeometry.CapRound, QgsGeometry.JoinStyleMiter, 2.0000)
        rectLeft = linea.singleSidedBuffer(self.ancho_riego, 0, 0, QgsGeometry.JoinStyleMiter, 2.0000)
        rectRight = linea.singleSidedBuffer(self.ancho_riego, 0, 1, QgsGeometry.JoinStyleMiter, 2.0000)
        area_riego = rectLeft.combine(rectRight)

        area_cruza = None
        area_no_cruza = None

        for poligono in self.pry.layer_canchas.getFeatures(area_riego.boundingBox()):
            if area_riego.intersects(poligono.geometry()):
                if linea.intersects(poligono.geometry()):
                    if not area_cruza:
                        area_cruza = poligono.geometry().intersection(area_riego)
                    else:
                        area_cruza = area_cruza.combine(poligono.geometry().intersection(area_riego))
                else:
                    if not area_no_cruza:
                        area_no_cruza = poligono.geometry().intersection(area_riego)
                    else:
                        area_no_cruza = area_no_cruza.combine(poligono.geometry().intersection(area_riego))

        self.pry.layer_lineas.changeGeometry(self.linea.id(), linea)

        area_cruza = area_cruza if area_cruza else QgsGeometry()
        area_no_cruza = area_no_cruza if area_no_cruza else QgsGeometry()

        atributos = {
            self.long_idx: f"{linea.length():.2f}",
            self.area_idx: f"{((area_cruza.area() + area_no_cruza.area()) / 10000):.2f}"
        }
        self.pry.layer_lineas.changeAttributeValues(self.linea.id(), atributos)
        self.linea = self.pry.layer_lineas.getFeature(self.linea.id())

        self.pry.layer_mangas.changeGeometry(self.manga.id(), manga)
        self.manga = self.pry.layer_mangas.getFeature(self.manga.id())

        self.pry.layer_riegos.changeGeometry(self.riego_cruza.id(), area_cruza)
        self.pry.layer_riegos.changeGeometry(self.riego_no_cruza.id(), area_no_cruza)
        self.riego_cruza = self.pry.layer_riegos.getFeature(self.riego_cruza.id())
        self.riego_no_cruza = self.pry.layer_riegos.getFeature(self.riego_no_cruza.id())

        self.checkCapacidad()

        self.pry.layer_puntos.commitChanges()
        self.pry.layer_lineas.commitChanges()
        self.pry.layer_mangas.commitChanges()
        self.pry.layer_riegos.commitChanges()

        self.refreshCapas()

    def mangaSeCruzaAsiMisma(self, pts):
        cruza = False
        segmentos = zip(pts, pts[1:])
        lineas = []

        for p1, p2 in segmentos:
            lineas.append(QgsGeometry.fromPolylineXY([p1, p2]))

        while len(lineas) > 0 and not cruza:
            lactual = lineas.pop()

            for l in lineas:
                if not lactual.intersects(l) or lactual.equals(l):
                    continue

                point = lactual.intersection(l)

                bandera = False

                for p in pts:
                    gp = QgsGeometry.fromPointXY(QgsPointXY(p.x(), p.y()))
                    if gp.equals(point):
                        bandera = True
                        break

                if not bandera:
                    cruza = True
                    break

        return cruza

    def mangaCruzaOtraManga(self):
        cruza = False

        for l in self.pry.layer_lineas.getFeatures():
            if self.linea["id"] == l["id"]:
                continue

            if not self.linea.geometry().intersects(l.geometry()):
                continue

            point = self.linea.geometry().intersection(l.geometry())

            if not self.punto_inicial.geometry().equals(point):
                cruza = True
                break

        return cruza

    def checkCapacidad(self):
        if (float(self.linea["capacidad_max"]) - float(self.linea["area"])) <= 0:
            self.supero_capacidad = True
            self.rubberBand.setToGeometry(self.manga.geometry())
        else:
            self.supero_capacidad = False
            self.rubberBand.reset()

    def punto_final_taipas(self, punto):
        for contorno in self.pry.layer_contornos.getFeatures():
            if punto.geometry().intersects(contorno.geometry()):
                return contorno['taipas']

        return "--"

    def refreshCapas(self):
        self.pry.layer_puntos.triggerRepaint()
        self.pry.layer_lineas.triggerRepaint()
        self.pry.layer_mangas.triggerRepaint()
        self.pry.layer_riegos.triggerRepaint()
        self.canvas.refresh()

    def deactivate(self):
        if self.rubberBand:
            self.canvas.scene().removeItem(self.rubberBand)
            self.rubberBand = None

        self.setCursor(Qt.ArrowCursor)


class DelMangasTool(QgsMapToolIdentify):

    def __init__(self, pry):
        self.canvas = pry.iface.mapCanvas()
        self.pry = pry
        self.feature = None
        QgsMapToolIdentify.__init__(self, self.canvas)
        self.setCursor(Qt.CrossCursor)
        self.pry.iface.messageBar().pushMessage("Click inzquierdo para eliminar | ENTER o ESC para salir!",
                               level=Qgis.Info, duration=5)

    def canvasPressEvent(self, event):
        found_features = self.identify(event.x(), event.y(), [self.pry.layer_mangas], self.TopDownAll)
        if len(found_features) > 0:
            self.feature = QgsFeature(found_features[0].mFeature)
        else:
            self.feature = None

    def canvasReleaseEvent(self, event):
        found_features = self.identify(event.x(), event.y(), [self.pry.layer_mangas], self.TopDownAll)
        if len(found_features) == 0:
            return

        if not self.feature.id() == found_features[0].mFeature.id():
            return

        linea_id = self.feature["id"]
        if getLineasHijas(linea_id, self.pry.layer_lineas):
            QMessageBox.warning(self.canvas, "Error",
                                "No se puede eliminar una manga con mangas hijas!")
            return

        riego_cruza = getRiego(linea_id, self.pry.layer_riegos, "CRUZAMANGA")
        if riego_cruza:
            self.pry.layer_riegos.dataProvider().deleteFeatures([riego_cruza.id()])

        riego_no_cruza = getRiego(linea_id, self.pry.layer_riegos, "NOCRUZAMANGA")
        if riego_no_cruza:
            self.pry.layer_riegos.dataProvider().deleteFeatures([riego_no_cruza.id()])

        linea = getFeatureById(linea_id, self.pry.layer_lineas)
        if linea:
            punto = getFeatureById(linea["punto_final_id"], self.pry.layer_puntos)
            self.pry.layer_lineas.dataProvider().deleteFeatures([linea.id()])
            if punto:
                self.pry.layer_puntos.dataProvider().deleteFeatures([punto.id()])

        compuertas = getCompuertas(linea_id, self.pry.layer_compuertas)
        ids_comp = []
        ids_riegos = []
        for c in compuertas:
            riego_compuerta = getFeatureById(c["id"], self.pry.layer_riegos_compuertas)
            if riego_compuerta:
                ids_riegos.append(riego_compuerta.id())

            ids_comp.append(c.id())

        self.pry.layer_compuertas.dataProvider().deleteFeatures(ids_comp)
        self.pry.layer_riegos_compuertas.dataProvider().deleteFeatures(ids_riegos)

        self.pry.layer_mangas.dataProvider().deleteFeatures([self.feature.id()])

        self.pry.layer_puntos.triggerRepaint()
        self.pry.layer_compuertas.triggerRepaint()
        self.pry.layer_lineas.triggerRepaint()
        self.pry.layer_mangas.triggerRepaint()
        self.pry.layer_riegos.triggerRepaint()
        self.pry.layer_riegos_compuertas.triggerRepaint()
        self.canvas.refresh()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape or event.key() == Qt.Key_Enter or event.key() == Qt.Key_Return:
            self.deactivate()

    def deactivate(self):
        self.setCursor(Qt.ArrowCursor)


class AbrirCerrarCompuertaTool(QgsMapToolIdentify):

    def __init__(self, pry):
        self.canvas = pry.iface.mapCanvas()
        self.pry = pry
        self.estado_idx = self.pry.layer_compuertas.fields().indexOf("estado")
        self.riego_estado_idx = self.pry.layer_riegos_compuertas.fields().indexOf("estado")
        QgsMapToolIdentify.__init__(self, self.canvas)

        self.setCursor(Qt.CrossCursor)
        self.pry.iface.messageBar().pushMessage("Click en el punto para seleccionar | ENTER o ESC para salir!",
                               level=Qgis.Info, duration=5)

    def canvasReleaseEvent(self, event):
        found_features = self.identify(event.x(), event.y(), [self.pry.layer_compuertas], self.TopDownStopAtFirst)
        if len(found_features) == 0:
            return

        compuerta = found_features[0].mFeature

        if compuerta["estado"] == 1:
            estado = 0
            riego_estado = "cerrado"
        else:
            estado = 1
            riego_estado = "abierto"

        self.pry.layer_compuertas.startEditing()
        self.pry.layer_compuertas.changeAttributeValue(compuerta.id(), self.estado_idx, estado)
        self.pry.layer_compuertas.commitChanges()

        riego_compuerta = getFeatureById(compuerta["id"], self.pry.layer_riegos_compuertas)
        if riego_compuerta:
            self.pry.layer_riegos_compuertas.startEditing()
            self.pry.layer_riegos_compuertas.changeAttributeValue(riego_compuerta.id(), self.riego_estado_idx, riego_estado)
            self.pry.layer_riegos_compuertas.commitChanges()

        self.pry.layer_compuertas.triggerRepaint()
        self.pry.layer_riegos_compuertas.triggerRepaint()
        self.canvas.refresh()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape or event.key() == Qt.Key_Enter or event.key() == Qt.Key_Return:
            self.deactivate()

    def deactivate(self):
        self.setCursor(Qt.ArrowCursor)


class AddCompuertasTool(QgsMapToolIdentify):

    def __init__(self, pry):
        self.canvas = pry.iface.mapCanvas()
        self.pry = pry
        QgsMapToolIdentify.__init__(self, self.canvas)

        self.tipos = ['1,2ha', '1,5ha']
        self.ancho_riego = self.pry.wnd.ancho_riego.value()
        self.manga = None
        self.linea_id = None
        self.limite = None
        self.tipo = None

        self.msg_tipos = QMessageBox(QMessageBox.Question, "Tipo de Compuerta", "Seleccione el tipo de compuerta",
                                     QMessageBox.Cancel, self.canvas)
        for tipo in self.tipos:
            self.msg_tipos.addButton(tipo, QMessageBox.YesRole)

        self.setCursor(Qt.CrossCursor)
        self.pry.iface.messageBar().pushMessage("Click en la manga para seleccionar | ENTER o ESC para salir!",
                               level=Qgis.Info, duration=5)

    def canvasReleaseEvent(self, event):
        found_features = self.identify(event.x(), event.y(), [self.pry.layer_mangas], self.TopDownStopAtFirst)
        if len(found_features) == 0:
            return

        self.tipo = self.msg_tipos.exec_()

        if self.tipo == QMessageBox.Cancel:
            return
        elif self.tipo == 0:
            self.limite = self.pry.wnd.max_comp_12.value() * 10000
        elif self.tipo == 1:
            self.limite = self.pry.wnd.max_comp_15.value() * 10000

        self.manga = found_features[0].mFeature
        self.linea_id = self.manga['id']

        eliminarCompuertas(self.linea_id, self.pry.layer_compuertas, self.pry.layer_riegos_compuertas)
        self.canvas.refresh()

        linea = getFeatureById(self.linea_id, self.pry.layer_lineas)

        layer_linea = QgsVectorLayer("LineString?crs=epsg:32721", "Segmentos", "memory")
        layer_linea.dataProvider().addFeatures([linea])

        params =  {
            'INPUT': layer_linea,
            'OVERLAY': self.pry.layer_contornos,
            'INPUT_FIELDS': [],
            'OVERLAY_FIELDS': [],
            'OVERLAY_FIELDS_PREFIX': '',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        res = processing.run("native:intersection", params)
        layer_segmentos = res['OUTPUT']

        for segmento in layer_segmentos.getFeatures():
            self.generarCompuertasSegmento(segmento)

    def generarCompuertasSegmento(self, segmento):
        # sentido de la linea
        pto_i, pto_f, linea_sentido = self.getLineaSentido(segmento)
        cortes_segmento = self.getCortesLineaPoligonos(segmento)

        for lado in [0, 1]:
            self.generarCompuertasLado(segmento, cortes_segmento, pto_i, linea_sentido, lado)

    def generarCompuertasLado(self, linea, cortes, pto_i, sentido, lado):
        # interseccion entre el area de riego y los poligonos
        lado_buffer = linea.geometry().singleSidedBuffer(self.ancho_riego, 0, lado, QgsGeometry.JoinStyleMiter, 2.0000)
        lado_feat = QgsFeature()
        lado_feat.setGeometry(lado_buffer)
        layer_lado_buffer = QgsVectorLayer("multipolygon?crs=epsg:32721", "", "memory")
        layer_lado_buffer.dataProvider().addFeatures([lado_feat])

        params = {
            "INPUT": self.pry.layer_canchas,
            "OVERLAY": layer_lado_buffer,
            'INPUT_FIELDS': [],
            'OVERLAY_FIELDS': [],
            'OVERLAY_FIELDS_PREFIX': '',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }
        res = processing.run("native:intersection", params)
        layer_poligonos = res["OUTPUT"]

        # quitar poligonos que no tocan la linea
        ids_pol = []
        linea_buff = linea.geometry().buffer(1, 5)
        for p in layer_poligonos.getFeatures():
            if not linea_buff.intersects(p.geometry()):
                ids_pol.append(p.id())
        layer_poligonos.dataProvider().deleteFeatures(ids_pol)
        # layer_poligonos.setName(f"poligonos manga {self.linea_id} lado: {lado} toca manga")
        # QgsProject.instance().addMapLayer(layer_poligonos)

        # contorno de riego
        params ={
            'INPUT': layer_poligonos,
            'FIELD': [],
            'OUTPUT':
            'TEMPORARY_OUTPUT'
        }
        res = processing.run("native:dissolve", params)
        layer_dis = res["OUTPUT"]
        contorno_riego = [f for f in layer_dis.getFeatures()][0]

        # aplicar limites de acuerdo a las mangas cercanas
        for l in self.pry.layer_lineas.getFeatures():
            if l['id'] == self.linea_id:
                continue

            if lado_buffer.intersects(l.geometry()):
                geom = contorno_riego.geometry().intersection(l.geometry())
                if len([v for v in geom.vertices()]) > 1:
                    layer_poligonos = self.cortarPoligonos(layer_poligonos, l, lado, sentido)

        # aplicar limites de acuerdo a los demas riegos
        params = {
            'INPUT': layer_poligonos,
            'OVERLAY': self.pry.layer_riegos_compuertas,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }
        res = processing.run("native:difference", params)
        layer_poligonos = res["OUTPUT"]

        # lista de poligonos a usar
        poligonos = [p for p in layer_poligonos.getFeatures()]

        # verificar si hay suficientes poligonos
        if len(poligonos) == 0:
            return

        area = 0
        for p in poligonos:
            area += p.geometry().area()

        if area < 10:
            return

        # agregar primer copuerta
        compuerta_geom = self.getPrimerCompuertaGeometry(pto_i, cortes, poligonos, lado)
        if not compuerta_geom:
            return

        compuerta = self.agregarCompuerta(linea, compuerta_geom, self.tipo)
        if not compuerta:
            return

        primer_poligono = self.getPrimerPoligonoRiego(compuerta.geometry(), poligonos)
        ids, riego_comp_geom = self.generarRiegoCompuerta(primer_poligono, poligonos, self.limite)
        self.agregarRiegoCompuerta(compuerta, riego_comp_geom)
        poligonos = [p for p in poligonos if p.id() not in ids]

        while len(poligonos) > 0:
            primer_poligono = self.getPrimerPoligonoRiego(riego_comp_geom, poligonos)
            if not primer_poligono:
                break
            # agregar compuerta
            rect = self.manga.geometry().intersection(primer_poligono.geometry())
            if not rect:
                break
            compuerta = self.agregarCompuerta(linea, rect.centroid(), self.tipo)
            ids, riego_comp_geom = self.generarRiegoCompuerta(primer_poligono, poligonos, self.limite)
            self.agregarRiegoCompuerta(compuerta, riego_comp_geom)
            poligonos = [p for p in poligonos if p.id() not in ids]

    def getCortesLineaPoligonos(self, linea):
        # intersecciones entre la linea y los poligonos
        segmentos = []
        for p in self.pry.layer_canchas.getFeatures():
            if p.geometry().intersects(linea.geometry()):
                segmentos.append(linea.geometry().intersection(p.geometry()))

        return segmentos

    def cortarPoligonos(self, layer_poligonos, linea_corte, lado, linea_sentido):
        pto1, pto2, sentido = self.getLineaSentido(linea_corte)

        if sentido == linea_sentido:
            i = lado
        else:
            i = 0 if lado == 1 else 1

        # interseccion entre el area de riego y los poligonos
        buffer_corte = linea_corte.geometry().singleSidedBuffer(self.ancho_riego, 0, i, QgsGeometry.JoinStyleMiter, 2.0000)
        lado_feat = QgsFeature()
        lado_feat.setGeometry(buffer_corte)
        layer_buffer_corte = QgsVectorLayer("multipolygon?crs=epsg:32721", "", "memory")
        layer_buffer_corte.dataProvider().addFeatures([lado_feat])

        params = {
            'INPUT': layer_poligonos,
            'OVERLAY': layer_buffer_corte,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }
        res = processing.run("native:difference", params)
        return res["OUTPUT"]
        # new_layer_pol.setName(f"poligonos manga {self.linea_id} cortados con {linea_corte['id']}")
        # return QgsProject.instance().addMapLayer(new_layer_pol)

    def getPrimerCompuertaGeometry(self, pto_i, segmentos, poligonos, lado):
        # busco el segmento mas cercano al punto inicial
        punto_geom = None
        min_dist = None

        for segmento in segmentos:
            pto_seg = [v for v in segmento.vertices()][0]
            dist = pto_i.distance(pto_seg)

            if min_dist is None or dist < min_dist:
                rect = segmento.singleSidedBuffer(3, 0, lado, QgsGeometry.JoinStyleMiter, 2.0000)
                punto = QgsFeature()
                punto.setGeometry(rect.centroid())

                punto_toca_poligono = False
                for p in poligonos:
                    if p.geometry().intersects(punto.geometry()):
                        punto_toca_poligono = True

                if punto_toca_poligono:
                    min_dist = dist
                    punto_geom = punto.geometry()

        return punto_geom

    def getCompuertaGeometry(self, linea, poligono, lado):
        segmento = linea.geometry().intersection(poligono.geometry())
        rect = segmento.singleSidedBuffer(3, 0, lado, QgsGeometry.JoinStyleMiter, 2.0000)
        return rect.centroid()

    def getPrimerPoligonoRiego(self, geom, poligonos):
        for p in poligonos:
            if geom.intersects(p.geometry()):
                return p

        return None

    def generarRiegoCompuerta(self, primer_poligono, poligonos, limite):
        geom = primer_poligono.geometry()
        ids = [primer_poligono.id()]
        SEGUIR = True

        while SEGUIR:
            SEGUIR = False

            for p in poligonos:
                if p.id() in ids:
                    continue

                if p.geometry().intersects(geom):
                    SEGUIR = True
                    new_geom = geom.combine(p.geometry()).removeInteriorRings()

                    if new_geom.area() >= limite:
                        SEGUIR = False
                        break
                    else:
                        geom = new_geom
                        ids.append(p.id())

        return ids, geom

    def agregarRiegoCompuerta(self, compuerta, riego_geom):
        riego_comp = QgsFeature(self.pry.layer_riegos_compuertas.fields())
        riego_comp["id"] = compuerta["id"]
        riego_comp["superficie"] = riego_geom.area()
        riego_comp["estado"] = 'abierto' if compuerta['estado'] == 1 else 'cerrado'
        riego_comp.setGeometry(riego_geom)
        self.pry.layer_riegos_compuertas.dataProvider().addFeatures([riego_comp])
        self.pry.layer_riegos_compuertas.triggerRepaint()

    def agregarCompuerta(self, linea, comp_geom, tipo):
        comp = QgsFeature(self.pry.layer_compuertas.fields())
        comp["id"] = getNextId(self.pry.layer_compuertas)
        comp["manga_id"] = self.linea_id
        comp["tipo"] = tipo
        comp["estado"] = 1
        comp.setGeometry(comp_geom)
        res, feats = self.pry.layer_compuertas.dataProvider().addFeatures([comp])
        self.pry.layer_compuertas.triggerRepaint()
        if res:
            return feats[0]
        else:
            return None

    def getLineaSentido(self, linea):
        vertices = [v for v in linea.geometry().vertices()]
        pto_i = vertices[0]
        pto_f = vertices[-1]
        azimuth = pto_i.azimuth(pto_f)

        if 0 <= abs(azimuth) <= 90:
            return pto_i, pto_f, 1
        else:
            return pto_i, pto_f, -1

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape or event.key() == Qt.Key_Enter or event.key() == Qt.Key_Return:
            self.deactivate()

    def deactivate(self):
        self.setCursor(Qt.ArrowCursor)


class DelCompuertasTool(QgsMapToolIdentify):

    def __init__(self, pry):
        self.canvas = pry.iface.mapCanvas()
        self.pry = pry
        QgsMapToolIdentify.__init__(self, self.canvas)

        self.setCursor(Qt.CrossCursor)
        self.pry.iface.messageBar().pushMessage("Click inzquierdo para seleccionar la manga | ENTER o ESC para salir!",
                               level=Qgis.Info, duration=5)

    def canvasReleaseEvent(self, event):
        found_features = self.identify(event.x(), event.y(), [self.pry.layer_mangas], self.TopDownAll)
        if len(found_features) == 0:
            return

        manga = found_features[0].mFeature
        eliminarCompuertas(manga['id'], self.pry.layer_compuertas, self.pry.layer_riegos_compuertas)
        self.canvas.refresh()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape or event.key() == Qt.Key_Enter or event.key() == Qt.Key_Return:
            self.deactivate()

    def deactivate(self):
        self.setCursor(Qt.ArrowCursor)